// Loading Screen
window.addEventListener('load', function() {
    const loadingScreen = document.getElementById('loadingScreen');
    setTimeout(() => {
        loadingScreen.classList.add('hidden');
        setTimeout(() => {
            loadingScreen.style.display = 'none';
        }, 500);
    }, 1000);
});

// Theme Toggle
const themeToggle = document.getElementById('themeToggle');
const themeIcon = themeToggle.querySelector('i');

// Check for saved theme preference or default to light
const currentTheme = localStorage.getItem('theme') || 'light';
document.documentElement.setAttribute('data-theme', currentTheme);
updateThemeIcon(currentTheme);

themeToggle.addEventListener('click', function() {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';
    
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    updateThemeIcon(newTheme);
    
    // Add animation to toggle button
    themeToggle.style.transform = 'scale(0.9)';
    setTimeout(() => {
        themeToggle.style.transform = 'scale(1)';
    }, 150);
});

function updateThemeIcon(theme) {
    if (theme === 'dark') {
        themeIcon.className = 'fas fa-sun';
    } else {
        themeIcon.className = 'fas fa-moon';
    }
}

// Scroll to Top Button
const scrollToTopBtn = document.getElementById('scrollToTop');

window.addEventListener('scroll', function() {
    if (window.pageYOffset > 300) {
        scrollToTopBtn.classList.add('show');
    } else {
        scrollToTopBtn.classList.remove('show');
    }
});

scrollToTopBtn.addEventListener('click', function() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
});

// Navigation
const navButtons = document.querySelectorAll('.nav-btn');
const pages = document.querySelectorAll('.page');

navButtons.forEach(button => {
    button.addEventListener('click', function() {
        const targetPage = this.getAttribute('data-page');
        
        // Update active nav button
        navButtons.forEach(btn => btn.classList.remove('active'));
        this.classList.add('active');
        
        // Show target page
        pages.forEach(page => {
            page.classList.remove('active');
            if (page.id === targetPage) {
                page.classList.add('active');
            }
        });
        
        // Scroll to top of page
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
});

// Particle Background
function createParticles() {
    const particlesContainer = document.getElementById('particlesContainer');
    const particleCount = 30;
    
    for (let i = 0; i < particleCount; i++) {
        const particle = document.createElement('div');
        particle.classList.add('particle');
        
        // Random size between 3px and 8px
        const size = Math.random() * 5 + 3;
        particle.style.width = `${size}px`;
        particle.style.height = `${size}px`;
        
        // Random position
        particle.style.left = `${Math.random() * 100}%`;
        particle.style.top = `${Math.random() * 100}%`;
        
        // Random animation delay and duration
        const delay = Math.random() * 15;
        const duration = Math.random() * 10 + 15;
        particle.style.animationDelay = `${delay}s`;
        particle.style.animationDuration = `${duration}s`;
        
        // Random color based on theme
        const colors = ['#4c956c', '#3a86ff', '#ff9e00'];
        const color = colors[Math.floor(Math.random() * colors.length)];
        particle.style.backgroundColor = color;
        
        particlesContainer.appendChild(particle);
    }
}

// Initialize particles
createParticles();

// Feedback Form Handling
const feedbackForm = document.getElementById('feedbackForm');
const successAlert = document.getElementById('successAlert');
const errorAlert = document.getElementById('errorAlert');
const criticismList = document.getElementById('criticismList');

// Load existing feedback from localStorage
loadFeedback();

feedbackForm.addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Get form data
    const name = document.getElementById('name').value;
    const role = document.getElementById('role').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;
    
    // Create feedback object
    const feedback = {
        name,
        role,
        email,
        message,
        date: new Date().toLocaleDateString('id-ID', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        })
    };
    
    // Save to localStorage
    saveFeedback(feedback);
    
    // Show success message
    successAlert.style.display = 'block';
    errorAlert.style.display = 'none';
    
    // Reset form
    feedbackForm.reset();
    
    // Reload feedback list
    loadFeedback();
    
    // Hide success message after 5 seconds
    setTimeout(() => {
        successAlert.style.display = 'none';
    }, 5000);
});

function saveFeedback(feedback) {
    let feedbacks = JSON.parse(localStorage.getItem('feedbacks')) || [];
    feedbacks.unshift(feedback); // Add to beginning of array
    localStorage.setItem('feedbacks', JSON.stringify(feedbacks));
}

function loadFeedback() {
    const feedbacks = JSON.parse(localStorage.getItem('feedbacks')) || [];
    criticismList.innerHTML = '';
    
    if (feedbacks.length === 0) {
        criticismList.innerHTML = '<p style="text-align: center; color: var(--text-color); opacity: 0.7;">Belum ada kritik dan saran.</p>';
        return;
    }
    
    feedbacks.forEach(feedback => {
        const criticismItem = document.createElement('div');
        criticismItem.classList.add('criticism-item');
        
        criticismItem.innerHTML = `
            <div class="criticism-header">
                <div>
                    <div class="criticism-name">${feedback.name}</div>
                    <div class="criticism-role">${getRoleDisplayName(feedback.role)}</div>
                </div>
                <div class="criticism-date">${feedback.date}</div>
            </div>
            <div class="criticism-message">${feedback.message}</div>
        `;
        
        criticismList.appendChild(criticismItem);
    });
}

function getRoleDisplayName(role) {
    const roleMap = {
        'mahasiswa': 'Mahasiswa',
        'dosen': 'Dosen',
        'staff': 'Staff',
        'alumni': 'Alumni',
        'masyarakat': 'Masyarakat Umum'
    };
    
    return roleMap[role] || role;
}

// Gallery Image Error Handling
document.querySelectorAll('.gallery-item img').forEach(img => {
    img.addEventListener('error', function() {
        this.src = 'https://via.placeholder.com/300x200/4c956c/ffffff?text=Gambar+Tidak+Tersedia';
        this.alt = 'Gambar tidak tersedia';
    });
});

// Member Image Error Handling
document.querySelectorAll('.member-img img').forEach(img => {
    img.addEventListener('error', function() {
        this.src = 'https://via.placeholder.com/300x200/3a86ff/ffffff?text=Foto+Anggota';
        this.alt = 'Foto anggota tidak tersedia';
    });
});

// Logo Image Error Handling
document.querySelector('.univ-logo img').addEventListener('error', function() {
    this.src = 'https://via.placeholder.com/100/2c6e49/ffffff?text=UNMUS';
    this.alt = 'Logo Universitas Musamus';
});

// Add hover effect to cards
document.querySelectorAll('.card').forEach(card => {
    card.addEventListener('mouseenter', function() {
        this.style.transform = 'translateY(-5px)';
    });
    
    card.addEventListener('mouseleave', function() {
        this.style.transform = 'translateY(0)';
    });
});

// Add animation to initiative items on scroll
function animateOnScroll() {
    const initiatives = document.querySelectorAll('.initiative');
    
    initiatives.forEach(initiative => {
        const initiativeTop = initiative.getBoundingClientRect().top;
        const windowHeight = window.innerHeight;
        
        if (initiativeTop < windowHeight - 100) {
            initiative.style.opacity = '1';
            initiative.style.transform = 'translateX(0)';
        }
    });
}

// Initialize initiative animations
document.querySelectorAll('.initiative').forEach(initiative => {
    initiative.style.opacity = '0';
    initiative.style.transform = 'translateX(-20px)';
    initiative.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
});

window.addEventListener('scroll', animateOnScroll);
animateOnScroll(); // Run once on load

// Add typing effect to header subtitle
function typeWriter(element, text, speed = 50) {
    let i = 0;
    element.innerHTML = '';
    
    function type() {
        if (i < text.length) {
            element.innerHTML += text.charAt(i);
            i++;
            setTimeout(type, speed);
        }
    }
    
    type();
}

// Initialize typing effect after page loads
window.addEventListener('load', function() {
    const subtitle = document.querySelector('.subtitle');
    const originalText = subtitle.textContent;
    typeWriter(subtitle, originalText);
});